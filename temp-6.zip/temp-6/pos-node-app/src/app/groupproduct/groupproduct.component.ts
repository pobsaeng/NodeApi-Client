import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { FormControl, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { GroupproductService } from './groupproduct.service';
import { DateFormatPipe } from '../common/dateformat.pipe';
import { DateTimeFormatPipe } from '../common/DateTimeFormat.pipe';
import * as $ from 'jquery';

@Component({
  selector: 'app-groupproduct',
  templateUrl: './groupproduct.component.html',
  styleUrls: ['./groupproduct.component.css']
})
export class GroupproductComponent implements OnInit, AfterViewInit {
  ngAfterViewInit(): void {
    console.log('ngAfterViewInit already!');
  }
  @ViewChild('mytable') tableRef: ElementRef;
  isValidFormSubmitted = null;
  isValidSearchFormSubmitted = null;

  ShowEditTable: Boolean = false;
  EditRowID: any = '';
  previousID: any = '';
  EditRowIDStatus: any = '';
  isEditRowIDActive: Boolean = false;

  public myFormGroup: FormGroup;
  public groupAddForm: FormGroup;
  public groupSearchForm: FormGroup;
  public switcher: FormGroup;
  public groupEditForm: FormGroup;
  listOfGroupProduct: any = '';
  listOfGroupProductTemp: any = '';
  groupProductTemp: any = '';

  public GROUP_PRODUCT_TYPE = {
    ADD: "เพิ่มกลุ่มสินค้า",
    SEARCH: "ค้นหา/แก้ไข"
  };
  constructor(
    private formBuilder: FormBuilder,
    private groupproductService: GroupproductService,
    private dateTimeFormat: DateTimeFormatPipe) {

    this.myFormGroup = this.formBuilder.group({
      switcher: this.formBuilder.group({
        type: [''],
        SEARCH: this.formBuilder.group({}),
        ADD: this.formBuilder.group({}),
      })
    });

    //first display
    this.setFormDisplay(this.GROUP_PRODUCT_TYPE.ADD);

    this.groupAddForm = this.formBuilder.group({
      group_product_id: [null],
      group_product_code: [null, [Validators.required, Validators.pattern("^[A-Z0-9_-]{8}$")]],
      group_product_name: [null, [Validators.required]],
      group_product_detail: [null, [Validators.required]],
      group_product_created_date: [new DateFormatPipe().transform(new Date(), ['local'])],
      group_product_last_update: [new DateFormatPipe().transform(new Date(), ['local'])]
    });

    this.groupSearchForm = this.formBuilder.group({
      group_product_search: [null, [Validators.required]]
    });

    this.groupEditForm = this.formBuilder.group({
      group_product_code: [null, [Validators.required, Validators.pattern("^[A-Z0-9_-]{8}$")]],
      group_product_name: [null, [Validators.required]],
      group_product_detail: [null, [Validators.required]],
    });
  }

  ngOnInit() { }

  setFormDisplay(type: string) {
    const ctrl = this.myFormGroup.get('switcher.type');
    ctrl.setValue(type);
  }

  @Input() message = { body: '', type: '' };
  setMsg(body, type, time = 3000) {
    this.message.body = body;
    this.message.type = type;
    setTimeout(() => { this.message.body = ''; }, time);
  }
  closeMsg() {
    this.setMsg('', '', 0);
  }
  onFormSubmit() {
    this.isValidFormSubmitted = false;
    if (this.groupAddForm.invalid) {
      return;
    }
    this.isValidFormSubmitted = true;
    //asign the value of a form and insert data
    let groupproduct: any = this.groupAddForm.value;
    delete groupproduct['group_product_id']; //don't need group_product_id

    let datetime = this.dateTimeFormat.transform(new Date());
    groupproduct.group_product_created_date = datetime;
    groupproduct.group_product_last_update = datetime;

    //calling service
    let me = this;
    this.groupproductService.create(groupproduct, function (result) {
      if (result.affectedRows > 0) {
        me.setMsg('Insert Complete!', 'info');
        me.groupAddForm.reset(); //set this form reset

      } else {
        me.setMsg('Insert failure!', 'danger');
      }
    });
  }
  //create a get attribute for FormBuilder
  get group_product_code() {
    return this.groupAddForm.get('group_product_code');
  }
  get group_product_name() {
    return this.groupAddForm.get('group_product_name');
  }
  get group_product_detail() {
    return this.groupAddForm.get('group_product_detail');
  }
  get group_product_search() {
    return this.groupSearchForm.get('group_product_search');
  }
  disabledButtons(index, bool) {
    let rows = this.tableRef.nativeElement.rows;
    for (let j = 1; j < rows.length; j++) {
      let button = rows[j].cells.item(index).getElementsByTagName("*");
      for (let i = 0; i < button.length; i++) {
        button[i].disabled = bool;
      }
    }
  }
  onEdit(groupproduct) {
    this.disabledButtons(3, true); //all disable edit button
    let id = groupproduct.group_product_id;

    if (!this.isEditRowIDActive) {
      //open edit cell
      this.isEditRowIDActive = true;
      this.EditRowID = id;
      this.groupProductTemp = groupproduct //keep previous groupproduct

    } else {
      //close edit cell without pressing the cancel button
      this.isEditRowIDActive = false;
      this.EditRowID = '';
      //retrieve data to previous row
      this.retriveDataTemp(this.groupProductTemp);
    }
    //save data to temp
    this.saveDataTemp(groupproduct);

  }
  saveDataTemp(groupproduct) {
    // let item = this.listOfGroupProduct.filter((gp_id: any) => gp_id.group_product_id === groupproduct.group_product_id);
    //asign the values to temp data
    // this.listOfGroupProductTemp = {
    //   group_product_id: groupproduct.group_product_id,
    //   group_product_code: groupproduct.group_product_code,
    //   group_product_name: groupproduct.group_product_name,
    //   group_product_detail: groupproduct.group_product_detail
    // };
    //copy the values to temp data
    this.listOfGroupProductTemp = Object.assign({}, groupproduct);
  }
  retriveDataTemp(groupproduct) {
    groupproduct.group_product_id = this.listOfGroupProductTemp.group_product_id;
    groupproduct.group_product_code = this.listOfGroupProductTemp.group_product_code;
    groupproduct.group_product_name = this.listOfGroupProductTemp.group_product_name;
    groupproduct.group_product_detail = this.listOfGroupProductTemp.group_product_detail;
  }
  onCancel(groupproduct) {
    this.disabledButtons(3, false); //all enable edit button
    this.EditRowID = '';
    this.isEditRowIDActive = false;

    // let item = this.listOfGroupProduct.filter((gp_id: any) => gp_id.group_product_id === groupproduct.group_product_id);
    groupproduct.group_product_id = this.listOfGroupProductTemp.group_product_id;
    groupproduct.group_product_code = this.listOfGroupProductTemp.group_product_code;
    groupproduct.group_product_name = this.listOfGroupProductTemp.group_product_name;
    groupproduct.group_product_detail = this.listOfGroupProductTemp.group_product_detail;
  }
  onSave(groupproduct) {
    this.EditRowID = '';
    this.isEditRowIDActive = false;

    this.isValidFormSubmitted = false;
    if (this.groupEditForm.invalid) {
      return;
    }
    this.isValidFormSubmitted = true;

    let group_product_created_date = this.dateTimeFormat.transform(groupproduct.group_product_created_date);
    let group_product_last_update = this.dateTimeFormat.transform(new Date());
    groupproduct.group_product_created_date = this.dateTimeFormat.transform(groupproduct.group_product_created_date);
    groupproduct.group_product_last_update = this.dateTimeFormat.transform(new Date());
    this.groupproductService.update(groupproduct); //update to service 
  }
  onSearch() {
    this.listOfGroupProduct = {};
    this.isEditRowIDActive = false;
    this.EditRowID = '';

    this.isValidSearchFormSubmitted = false;
    if (this.groupSearchForm.invalid) {
      return;
    }
    this.isValidSearchFormSubmitted = true;

    let value = this.groupSearchForm.value.group_product_search.trim();
    this.groupproductService.searchLike({ value: value })
      .subscribe(result => {
        console.log(result);

        if (result.success) {
          this.listOfGroupProduct = result.rows;

          //change format value of fields
          for (let item of this.listOfGroupProduct) {
            if (item.group_product_created_date) {
              item.group_product_created_date = this.dateTimeFormat.transform(item.group_product_created_date);
            }
            if (item.group_product_last_update) {
              item.group_product_last_update = this.dateTimeFormat.transform(item.group_product_created_date);
            }
          }

        } else {
          this.setMsg('not fond record!', 'danger');
        }
      });

  }
}
