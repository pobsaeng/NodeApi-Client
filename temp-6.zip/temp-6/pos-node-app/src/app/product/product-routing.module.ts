import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddproductComponent } from './addproduct.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [
  { path: 'addproduct', component: AddproductComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class ProductRoutingModule { }
