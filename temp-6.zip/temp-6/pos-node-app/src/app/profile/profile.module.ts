import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfileRoutingModule } from './profile-routing.module';
import { RegisterComponent } from './register/register.component';
import { ForgotpassComponent } from './forgotpass/forgotpass.component';
import { RegisterService } from './register/register.service';

@NgModule({
  imports: [
    FormsModule,
    // ReactiveFormsModule,
    CommonModule,
    ProfileRoutingModule
  ],
  declarations: [
    RegisterComponent,
    ForgotpassComponent
  ],
  providers: [
    RegisterService
  ]
})
export class ProfileModule { }
