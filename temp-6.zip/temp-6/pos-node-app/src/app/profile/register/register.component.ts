import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from './register.service';
import { Register } from './register.interface';
import { DateTimeFormatPipe } from '../../common/DateTimeFormat.pipe';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  userModel: Register[] = [];
  loading = false;

  ngOnInit() { }

  constructor(
    private router: Router,
    private registerService: RegisterService,
    private dateTimeFormat: DateTimeFormatPipe
  ) { }

  onRegisterFormSubmit() {
    this.userModel['id'] = '12154';
    let currdatetime = this.dateTimeFormat.transform(new Date());
    this.userModel['create_date'] = currdatetime;
    this.userModel['lastupdate'] = currdatetime;
    console.log(this.userModel);

    this.registerService.create(this.userModel, function () {

    });
    // this.registerService.create(user)
    //   .subscribe(
    //   data => {
    //      console.log(data);
    //     // this.router.navigate(['/login']);
    //   },
    //   error => {
    //     console.log(error);
    //   });
  }

}
