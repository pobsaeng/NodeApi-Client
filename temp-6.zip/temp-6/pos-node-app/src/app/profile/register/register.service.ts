import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { siteMap } from '../../common/sitemap';
import { DateTimeFormatPipe } from '../../common/DateTimeFormat.pipe';

@Injectable()
export class RegisterService {

  constructor(private http: Http, private dateTimeFormat: DateTimeFormatPipe) { }

  create(user: any, callback): Promise<any> {
    console.log(user);
    // let options = this.setHeaderAuthorization();
    // const { REGISTER } = siteMap().register;

    // return this.http
    //   .post(REGISTER, JSON.stringify(user), options)
    //   .toPromise()
    //   .then(res => {
    //     callback(res.json());
    //   })
    //   .catch(function (res) {
    //     callback(res.json());
    //   });
    return null;
  }
  // createRegister(article: Register): Observable<Register> {
  //   let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
  //   let options = new RequestOptions({ headers: cpHeaders });
  //   return this.http.post(this.articleUrl, article, options)
  //     .map(success => success.status)
  //     .catch(this.handleError);
  // }

  setHeaderAuthorization() {
    let token = sessionStorage.getItem('token');
    const headers = new Headers();
    // headers.append('XSRF-TOKEN', JSON.parse(token));
    headers.append('Content-Type', 'application/json');
    headers.append('authorization', JSON.parse(token));
    return new RequestOptions({ headers: headers });
  }
}
