export interface Register {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  password: string;
  passwordConfirm: string;
}
