'use strict';
const GroupProductController = require('../controllers/GroupProduct.Controller');

class GroupProductRoutes {
    constructor(app) {
        this.app = app;
        this.groupProductController = new GroupProductController();
    }
    appRoutes() {
        // this.app.get('/api/allgroupproduct, (request, response) => {
        //     this.groupProductController.getAllGroupProduct(request, response);
        // });

        this.app.post('/api/groupproduct/searchLike', (request, response) => {
            this.groupProductController.searchLike(request, response);
        });

        this.app.get('/api/groupproduct:findById:id', (request, response) => {
            this.groupProductController.getGroupProductById(request, response);
        });

        this.app.post('/api/groupproduct/insert', (request, response) => {
            this.groupProductController.insert(request, response);
        });

        this.app.post('/api/groupproduct/update', (request, response) => {
            this.groupProductController.update(request, response);
        });

        this.app.get('/api/groupproduct/remove:id', (request, response) => {
            this.groupProductController.remove(request, response);
        });

    }
    getRoutes() {
        this.appRoutes();
    }
}
module.exports = GroupProductRoutes;
