const BillSaleController = require('../controllers/BillSale.Controller');

class BillSaleRoutes {
    constructor(app) {
        this.app = app;
        this.billSaleController = new BillSaleController();
    }
    getRoutes() {

        this.app.get('/api/sale', (request, response) => {
            this.billSaleController.insert(request, response);
        });
    }
}
module.exports = BillSaleRoutes;