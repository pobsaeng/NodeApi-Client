const RegisterController = require('../controllers/Register.Controller');

class RegisterRoutes {
    constructor(app) {
        this.app = app;
        this.registerController = new RegisterController();
    }
    getRoutes() {
        this.app.get('/api/addproduct', (request, response) => {
            this.registerController.insert(request, response);
        });
    }
}
module.exports = RegisterRoutes;
