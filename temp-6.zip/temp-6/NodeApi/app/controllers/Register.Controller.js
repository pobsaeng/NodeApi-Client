const RegisterModel = require("../models/Register.Model");

class RegisterController {
    constructor() {
        this.registerModel = new RegisterModel();
    }
    insert(req, res) {
        this.registerModel.create(function (result) {
            res.send(result);
        });
    }
}
module.exports = RegisterController;
