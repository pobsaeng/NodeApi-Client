﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         10.100.60.178
# Database:                     dbquery
# Server version:               5.5.29
# Server OS:                    Win64
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2014-09-29 17:50:41
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'dbquery'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "dbquery" /*!40100 DEFAULT CHARACTER SET utf8 */;

USE "dbquery";


#
# Table structure for table 'author'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "author" (
  "aid" int(11) NOT NULL AUTO_INCREMENT,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("aid")
) AUTO_INCREMENT=7;



#
# Dumping data for table 'author'
#

LOCK TABLES "author" WRITE;
/*!40000 ALTER TABLE "author" DISABLE KEYS;*/
REPLACE INTO "author" ("aid", "name") VALUES
	(1,'Tim Dario');
REPLACE INTO "author" ("aid", "name") VALUES
	(2,'Asli Bilgin');
REPLACE INTO "author" ("aid", "name") VALUES
	(3,'Jason Price');
REPLACE INTO "author" ("aid", "name") VALUES
	(4,'John Merrall');
REPLACE INTO "author" ("aid", "name") VALUES
	(5,'Robin Aldale');
/*!40000 ALTER TABLE "author" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'book'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "book" (
  "title" varchar(255) NOT NULL,
  "author" varchar(20) DEFAULT NULL,
  "publisher" varchar(20) DEFAULT NULL,
  "publishdate" date DEFAULT NULL,
  "price" float DEFAULT NULL,
  PRIMARY KEY ("title")
);



#
# Dumping data for table 'book'
#

LOCK TABLES "book" WRITE;
/*!40000 ALTER TABLE "book" DISABLE KEYS;*/
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Enterprise JavaBeans','Tim Dario','O''Reilly','2001-10-15','45');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Java in a Nutshell','Asli Bilgin','O''Reilly','2003-03-01','40');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('XML in a Nutshell','Jason Price','O''Reilly','2002-12-15','40');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Java Enterprise','Tim Dario','O''Reilly','2002-12-01','35');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Php Functions Reference','John Merrall','Manning','2002-07-25','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Linux Firewalls','Robin Aldale','Manning','2001-10-24','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Inside Photoshop 7','Robin Aldale','Manning','2002-07-22','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Network Security','Judy Noval','Manning','2003-02-27','46');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Mastering Delphi 6','Marco Cantu','Sybex','2002-11-25','60');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Mastering VB.NET','Asli Bilgin','Sybex','2002-01-11','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Mastering Visual C#.NET','Jason Price','Sybex','2003-02-20','40');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Mastering Java Scripts','Cate McCoy','Sybex','2003-03-14','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Beginning Java 2 SDK','Tim Dario','Wrox','2003-03-01','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Professional PHP5','Chris Ullman','Wrox','2003-03-15','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Professional Apache 2.0','Judy Noval','Wrox','2002-12-01','50');
REPLACE INTO "book" ("title", "author", "publisher", "publishdate", "price") VALUES
	('Beginning VB.NET','Kim Blair','Wrox','2003-01-01','40');
/*!40000 ALTER TABLE "book" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'books'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "books" (
  "bid" int(10) unsigned NOT NULL AUTO_INCREMENT,
  "pid" int(10) unsigned NOT NULL,
  "title" varchar(255) NOT NULL,
  "amount" int(2) DEFAULT NULL,
  "aid" varchar(20) DEFAULT NULL,
  "publishdate" date NOT NULL,
  "price" mediumint(9) NOT NULL,
  PRIMARY KEY ("bid")
) AUTO_INCREMENT=22;



#
# Dumping data for table 'books'
#

LOCK TABLES "books" WRITE;
/*!40000 ALTER TABLE "books" DISABLE KEYS;*/
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('1','3','Mastering VB.NET',1,'1','2002-01-11',50);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('2','3','Mastering Visual C#.NET',3,'2','2003-02-20',40);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('3','3','Mastering Java Scripts',1,'3','2003-03-14',50);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('4','5','Professional PHP5',2,'1','2003-03-15',50);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('5','1','Linux Firewalls',4,'4','2001-10-24',49);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('6','1','Network Security',1,'5','2003-02-27',59);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('7','2','JSP Servlet ',NULL,NULL,'2014-01-01',65);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('8','2','Java Swing',2,'5','2014-02-05',75);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('9','4','JSP Tutorials',1,'3','2014-02-10',70);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('10','4','Hibernate Tutorials',NULL,'1','2014-01-12',65);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('11','5','Spring MVC',2,'3','2014-03-08',80);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('12','1','Struts v.2',5,'2','2014-03-15',100);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('13','5','JSF v.2',1,'1','2014-01-20',95);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('14','3','JSF v.1',NULL,'4','2014-01-07',89);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('15','2','Java Structure',3,'2','2014-02-13',77);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('16','1','J2EE Tutotials',1,'5','2014-02-24',0);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('17','1','Servlet Tutorials',3,NULL,'2014-04-04',99);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('18','4','Struts 2 + Spring + Hibernate',NULL,NULL,'2014-03-19',67);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('19','5','MySql Tip',4,'3','2014-01-11',0);
REPLACE INTO "books" ("bid", "pid", "title", "amount", "aid", "publishdate", "price") VALUES
	('20','3','Sql Server 2012',2,'2','2014-01-22',97);
/*!40000 ALTER TABLE "books" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'publisher'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "publisher" (
  "pid" int(11) NOT NULL AUTO_INCREMENT,
  "name" varchar(45) DEFAULT NULL,
  PRIMARY KEY ("pid"),
  UNIQUE KEY "name_UNIQUE" ("name")
) AUTO_INCREMENT=11;



#
# Dumping data for table 'publisher'
#

LOCK TABLES "publisher" WRITE;
/*!40000 ALTER TABLE "publisher" DISABLE KEYS;*/
REPLACE INTO "publisher" ("pid", "name") VALUES
	(1,'Manning');
REPLACE INTO "publisher" ("pid", "name") VALUES
	(3,'Sybex');
REPLACE INTO "publisher" ("pid", "name") VALUES
	(5,'Wrox');
REPLACE INTO "publisher" ("pid", "name") VALUES
	(4,'KTP');
REPLACE INTO "publisher" ("pid", "name") VALUES
	(2,'se-ed');
/*!40000 ALTER TABLE "publisher" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'textbook'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "textbook" (
  "bid" int(10) unsigned NOT NULL AUTO_INCREMENT,
  "pid" int(10) unsigned NOT NULL,
  "title" varchar(255) NOT NULL,
  "aid" varchar(20) DEFAULT NULL,
  "publishdate" date NOT NULL,
  "price" mediumint(9) NOT NULL,
  PRIMARY KEY ("bid")
) AUTO_INCREMENT=21;



#
# Dumping data for table 'textbook'
#

LOCK TABLES "textbook" WRITE;
/*!40000 ALTER TABLE "textbook" DISABLE KEYS;*/
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('1','3','Mastering VB.NET','1','2002-01-11',50);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('2','3','Mastering Visual C#.NET','2','2003-02-20',40);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('3','3','Mastering Java Scripts','3','2003-03-14',50);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('4','5','Professional PHP5','1','2003-03-15',50);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('5','1','Linux Firewalls','4','2001-10-24',49);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('6','1','Network Security','5','2003-02-27',59);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('7','2','JSP Servlet ',NULL,'2014-01-01',65);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('8','2','Java Swing','5','2014-02-05',75);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('9','4','JSP Tutorials','3','2014-02-10',70);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('10','4','Hibernate Tutorials','1','2014-01-12',65);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('11','5','Spring MVC','3','2014-03-08',80);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('12','1','Struts v.2','2','2014-03-15',100);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('13','5','JSF v.2','1','2014-01-20',95);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('14','3','JSF v.1','4','2014-01-07',89);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('15','2','Java Structure','2','2014-02-13',77);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('16','1','J2EE Tutotials','5','2014-02-24',0);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('17','1','Servlet Tutorials',NULL,'2014-04-04',99);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('18','4','Struts 2 + Spring + Hibernate',NULL,'2014-03-19',67);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('19','5','MySql Tip','3','2014-01-11',0);
REPLACE INTO "textbook" ("bid", "pid", "title", "aid", "publishdate", "price") VALUES
	('20','3','Sql Server 2012','2','2014-01-22',97);
/*!40000 ALTER TABLE "textbook" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'zoo'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "zoo" (
  "name" varchar(20) DEFAULT NULL,
  "type" varchar(20) DEFAULT NULL,
  "sex" char(1) DEFAULT NULL,
  "birth" date DEFAULT NULL,
  "death" date DEFAULT NULL
);



#
# Dumping data for table 'zoo'
#

LOCK TABLES "zoo" WRITE;
/*!40000 ALTER TABLE "zoo" DISABLE KEYS;*/
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Slim','snake','f','2000-12-25',NULL);
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Clipper','snake','m','2001-01-18',NULL);
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Jane','lion','f','2002-05-09','2003-04-05');
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Joey','lion','m','2003-01-08',NULL);
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Tuna','tiger','f','2003-03-15',NULL);
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Susu','tiger','f','2003-03-15','2003-03-31');
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Mike','tiger','m','2003-03-15',NULL);
REPLACE INTO "zoo" ("name", "type", "sex", "birth", "death") VALUES
	('Olive','bear','f','2003-03-15',NULL);
/*!40000 ALTER TABLE "zoo" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
