const GroupProductModel = require("../models/GroupProduct.Model");

class GroupProductController {
    constructor() {
        this.groupProductModel = new GroupProductModel();
    }
    insert(req, res) {
        this.groupProductModel.create(req.body, function (result) {
            res.send(result);
        });
    }
    update(req, res) {
        console.log(req.body);
        
        this.groupProductModel.update(req.body, function (result) {
            res.send(result);
        });
    }
    remove(req, res) {
        this.groupProductModel.delete(2, function (result) {
            res.send(result);
        });
    }
    getAllGroupProduct(req, res) {
        this.groupProductModel.findAll(function (result) {
            res.send(result);
        });
    }
    getGroupProductById(req, res) {
        this.groupProductModel.findById(3, function (result) {
            res.send(result);
        });
    }
    searchLike(req, res) {
        this.groupProductModel.findByLike(req.body.value, function (result) {
            res.send(result);
        });
    }
}
module.exports = GroupProductController;
