import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { GroupproductService } from './groupproduct.service';
import { DateFormatPipe } from '../common/dateformat.pipe';

@Component({
  selector: 'app-groupproduct',
  templateUrl: './groupproduct.component.html',
  styleUrls: ['./groupproduct.component.css']
})
export class GroupproductComponent implements OnInit {
  isValidFormSubmitted = null;
  public myForm: FormGroup;

  public GROUP_PRODUCT_TYPE = {
    ADD: 'เพิ่มกลุ่มสินค้า',
    EDIT: 'ค้นหา/แก้ไข'
  };

  constructor(
    private formBuilder: FormBuilder,
    private _fb: FormBuilder,
    private groupproductService: GroupproductService) {

    this.myForm = this._fb.group({
      switcher: this.initSwitcherGroupProduct()
    });

    this.setPaymentMethodType(this.GROUP_PRODUCT_TYPE.ADD);

  }

  ngOnInit() { }

  groupForm = this.formBuilder.group({
    group_product_id: [null],
    group_product_code: ['', [Validators.required, Validators.pattern("^[A-Z0-9_-]{8}$")]],
    group_product_name: ['', [Validators.required]],
    group_product_detail: ['', [Validators.required]],
    group_product_created_date: [new DateFormatPipe().transform(new Date(), ['local'])],
    group_product_last_update: [new DateFormatPipe().transform(new Date(), ['local'])]
  });

  @Input() message = { body: '', type: '' };
  setMsg(body, type, time = 3000) {
    this.message.body = body;
    this.message.type = type;
    setTimeout(() => { this.message.body = ''; }, time);
  }
  closeMsg() {
    this.setMsg('', '', 0);
  }
  onFormSubmit() {
    this.isValidFormSubmitted = false;
    if (this.groupForm.invalid) {
      return;
    }
    this.isValidFormSubmitted = true;
    let groupproduct: any = this.groupForm.value; //asign the value of a form to Groupproduct class
    this.groupproductService.create(groupproduct); //calling service
    this.setMsg('Insert Complete!', 'info'); //alert message is success
    this.groupForm.reset(); //set this form reset
  }
  //create a get attribute for FormBuilder
  get group_product_code() {
    return this.groupForm.get('group_product_code');
  }
  get group_product_name() {
    return this.groupForm.get('group_product_name');
  }
  get group_product_detail() {
    return this.groupForm.get('group_product_detail');
  }

  initSwitcherGroupProduct() {
    // initialize payment method form group
    const group = this._fb.group({
      type: [''],
      EDIT: this._fb.group(this.initPaymentMethodCardModel()),
      ADD: this._fb.group(this.initPaymentMethodADDModel()),
    });

    return group;
  }

  initPaymentMethodCardModel(): any {
    const model = {
      group_product_id: [null],
      group_product_code: ['', [Validators.required, Validators.pattern("^[A-Z0-9_-]{8}$")]],
      group_product_name: ['', [Validators.required]],
      group_product_detail: ['', [Validators.required]],
      group_product_created_date: [new DateFormatPipe().transform(new Date(), ['local'])],
      group_product_last_update: [new DateFormatPipe().transform(new Date(), ['local'])]
    };

    return model;
  }

  initPaymentMethodADDModel(): any {
    const model = {
      group_product_id: [null],
      group_product_code: ['', [Validators.required, Validators.pattern("^[A-Z0-9_-]{8}$")]],
      group_product_name: ['', [Validators.required]],
      group_product_detail: ['', [Validators.required]],
      group_product_created_date: [new DateFormatPipe().transform(new Date(), ['local'])],
      group_product_last_update: [new DateFormatPipe().transform(new Date(), ['local'])]
    };

    return model;
  }

  setPaymentMethodType(type: string) {
    // update payment method type value
    const ctrl = this.myForm.get('switcher.type');
    ctrl.setValue(type);
  }
}
