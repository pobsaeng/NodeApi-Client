'use strict';
const GroupProductController = require('../controllers/GroupProduct.Controller');

class GroupProductRoutes {
    constructor(app) {
        this.app = app;
        this.groupProductController = new GroupProductController();
    }
    appRoutes() {
        this.app.get('/api/allGroupProduct', (request, response) => {
            this.groupProductController.getAllGroupProduct(request, response);
        });

        this.app.get('/api/groupProductById:id', (request, response) => {
            this.groupProductController.getGroupProductById(request, response);
        });

        this.app.post('/api/groupProduct/insert', (request, response) => {
            this.groupProductController.insert(request, response);
        });

        this.app.get('/api/groupProduct/update:id', (request, response) => {
            this.groupProductController.update(request, response);
        });

        this.app.get('/api/groupProduct/remove:id', (request, response) => {
            this.groupProductController.remove(request, response);
        });

    }
    getRoutes() {
        this.appRoutes();
    }
}
module.exports = GroupProductRoutes;
