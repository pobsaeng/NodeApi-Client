const BillSaleModel = require('../models/BillSale.Model');

class BillSaleController {
    constructor() {
        this.billSaleModel = new BillSaleModel();
    }
    insert(req, res) {
        this.billSaleModel.create(function (result) {
            res.send(result);
        });
    }
}
module.exports = BillSaleController;